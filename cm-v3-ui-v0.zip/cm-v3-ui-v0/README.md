# About
This package is derived from Metaplex's Candy Machine UI.

The original Candy Machine UI does not work with Candy Machine V3. Key Strokes tweaked the existing Candy Machine UI for Candy Machine V2, and made it work for Candy Machine V3 for simple mint guards.

# Caution
Using this for production is not recommended, as this was created for demonstrating minting process.
If you end up using this, then its at your own risk, and the author's are not responsible for any damages, loss, unexpected behaviors or bugs.